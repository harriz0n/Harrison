
# Harrison Bent - Portfolio

This is my personal portfolio website built with TailwindCSS.

Sections include:
- Videos
- Strategic Mapping
- AI Projects

Hosted using GitHub Pages.
